--Registrations
USE Demo;
GO
SET STATISTICS IO ON ;


--Has 1,000,000 rows
--Original problem had 10,000 rows
SELECT TOP(100) * FROM Registrations
ORDER BY DateJoined;

SELECT COUNT(*) FROM Registrations;

-- new registrations per month  
SELECT  count(*) AS newRegistrations ,
        year(datejoined) AS Year ,
        month(datejoined) AS Month
FROM    REGISTRATIONS
GROUP BY year(datejoined) ,
        month(datejoined)
ORDER BY Year ,
        Month ;
        
-- Unsubscribes per month
SELECT  count(*) AS Cancellations ,
        year(dateleft) AS Year ,
        month(dateleft) AS Month
FROM    REGISTRATIONS
GROUP BY year(dateleft) ,
        month(dateleft)
ORDER BY Year ,
        Month ;


--How about a self-join? Takes a loooong time!
WITH 
PeopleJoined AS (
		SELECT  CAST(CAST(year(DateJoined) AS VARCHAR) + '-'
                + cast(month(DateJoined) AS VARCHAR) + '-1' AS DATE) AS DateJoined,
                count(*) AS PeopleJoined
        FROM    Registrations
		WHERE DateJoined < '1985-01-01'
        GROUP BY cast(year(DateJoined) AS VARCHAR) + '-'
                + cast(month(DateJoined) AS VARCHAR) + '-1'
	),
PeopleLeft AS (	
		SELECT  CAST(CAST(year(DateLeft) AS VARCHAR) + '-'
                + cast(month(DateLeft) AS VARCHAR) + '-1' AS DATE) AS DateLeft,
                count(*) AS PeopleLeft
        FROM    Registrations
		WHERE DateLeft < '1985-01-01'
        GROUP BY cast(year(DateLeft) AS VARCHAR) + '-'
                + cast(month(DateLeft) AS VARCHAR) + '-1'
	), 
CombinedData AS (
	SELECT DateJoined AS TheDate, PeopleJoined, ISNULL(PeopleLeft.PeopleLeft,0) AS PeopleLeft
	FROM PeopleJoined 
	LEFT JOIN PeopleLeft ON PeopleJoined.DateJoined = PeopleLeft.DateLeft)
SELECT TheDate, PeopleJoined, PeopleLeft,
	(SELECT SUM(PeopleJoined - PeopleLeft)
	FROM CombinedData 
	WHERE TheDate <= A.TheDate)
FROM CombinedData AS A
ORDER BY A.TheDate;

--Maybe use a cursor? 
--This was from 2009. That's ancient history for SQL Server!
DROP TABLE IF EXISTS #subscriptions; 
DECLARE @total INT
DECLARE @people_joined INT
DECLARE @people_left INT 
DECLARE @the_month DATETIME 
 
--create a table to hold the results
CREATE TABLE #subscriptions
    (
      theMonth DATETIME ,
      PeopleJoined INT ,
      PeopleLeft INT ,
      Subscriptions INT
    )
 
--insert a row for each month
--in the data
INSERT  INTO #subscriptions
        ( theMonth ,
          PeopleJoined ,
          PeopleLeft ,
          Subscriptions
        )
        SELECT  cast(year(DateJoined) AS VARCHAR) + '-'
                + cast(month(DateJoined) AS VARCHAR) + '-1' ,
                count(*) ,
                0 ,
                0
        FROM    Registrations
        GROUP BY cast(year(DateJoined) AS VARCHAR) + '-'
                + cast(month(DateJoined) AS VARCHAR) + '-1';
 
--update for cancellations

WITH    CANCELLATIONS
          AS ( SELECT   count(*) CANC_COUNT ,
                        cast(year(DateLeft) AS VARCHAR) + '-'
                        + cast(month(DateLeft) AS VARCHAR) + '-1' AS Dateleft
               FROM     Registrations
               WHERE    DATELEFT IS NOT NULL
               GROUP BY cast(year(DateLeft) AS VARCHAR) + '-'
                        + cast(month(DateLeft) AS VARCHAR) + '-1'
             )
    UPDATE  S
    SET     PeopleLeft = CANC_COUNT
    FROM    #subscriptions S
            INNER JOIN CANCELLATIONS C 
               ON S.theMonth = Dateleft
 
SET @total = 0
--set up a cursor to update the total subscriptions
--for each month
DECLARE SUBSCRIPTIONS CURSOR FOR
SELECT THEMONTH, PEOPLEJOINED, PEOPLELEFT
FROM #SUBSCRIPTIONS ORDER BY THEMONTH
 
OPEN SUBSCRIPTIONS
FETCH NEXT FROM SUBSCRIPTIONS INTO @the_month, @people_joined, 
   @people_left
WHILE @@FETCH_STATUS = 0 
    BEGIN
 
        SET @total = @total + @people_joined - 
                                  @people_left 
        UPDATE  #subscriptions
        SET     Subscriptions = @total
        WHERE   theMonth = @the_month 
 
        FETCH NEXT FROM SUBSCRIPTIONS 
           INTO @the_month, @people_joined, @people_left
    END
CLOSE SUBSCRIPTIONS
DEALLOCATE SUBSCRIPTIONS

--the report
SELECT  *
FROM    #subscriptions
ORDER BY THEMONTH;



--The modern solution
WITH    NewSubscriptions
          AS ( SELECT   EOMONTH([DateJoined]) AS DateJoined ,
                        COUNT(*) AS PeopleJoined
               FROM     Registrations
               GROUP BY EOMONTH([DateJoined])
             ),
        Cancellations
          AS ( SELECT   EOMONTH([DateLeft]) AS DateLeft ,
                        COUNT(*) AS PeopleLeft
               FROM     Registrations
               GROUP BY EOMONTH([DateLeft])
             )
    SELECT  DateJoined AS TheMonth ,
            PeopleJoined ,
            ISNULL(PeopleLeft, 0) AS PeopleLeft ,
            SUM(PeopleJoined - ISNULL(PeopleLeft, 0)) 
				OVER ( ORDER BY DateJoined
				ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW ) AS CurrentSubscriptions
    FROM    NewSubscriptions
            LEFT OUTER JOIN Cancellations ON DateJoined = DateLeft
    ORDER BY DateJoined;

