--Islands and gaps are easy with window functions!
USE DEMO
GO
DROP TABLE IF EXISTS SomeNumbers;
CREATE TABLE SomeNumbers (Number INT);

INSERT INTO dbo.SomeNumbers
(
    Number
)
VALUES (1),(2),(3),(4),(5),(8),(9),(10),(11),
	(13),(15),(16),(17);




SELECT * 
FROM SomeNumbers
ORDER BY Number;

/*
 1 - 5
 8 - 11
13 - 13 
15 - 17
*/



SELECT Number,
	ROW_NUMBER() OVER(ORDER BY Number) AS RowNum
FROM SomeNumbers
ORDER BY Number;

SELECT Number, Number - ROW_NUMBER() OVER(ORDER BY Number) AS DiffGroup
FROM SomeNumbers
ORDER BY Number;

--The islands solved by using row number!
WITH RowNums AS (
	SELECT Number - ROW_NUMBER() OVER(ORDER BY Number) AS DiffGroup,Number 
	FROM SomeNumbers)
SELECT MIN(Number) AS StartOfIsland, MAX(Number) AS EndOfIsland 
FROM RowNums
GROUP BY DiffGroup
ORDER BY MIN(Number);

--Gaps? 
/*
Island		Gap
 1 -  5		Add one to the end of the island,
			Subtract one from the beginning of the next island
			6 -  7 
 8 - 11	
		   12 - 12
13 - 13
		   14 - 14 
15 - 17

*/

WITH RowNums AS (
	SELECT Number - ROW_NUMBER() OVER(ORDER BY Number) AS DiffGroup,Number 
	FROM SomeNumbers),
Islands AS (
	SELECT MIN(Number) AS StartOfIsland, MAX(Number) AS EndOfIsland 
	FROM RowNums
	GROUP BY DiffGroup)
SELECT LAG(Islands.EndOfIsland) OVER(ORDER BY Islands.StartOfIsland) + 1 AS StartOfGap,
		Islands.StartOfIsland -1 EndOfGap
FROM Islands
ORDER BY Islands.StartOfIsland;

WITH RowNums AS ( --asdklkfjslkfj
	SELECT Number - ROW_NUMBER() OVER(ORDER BY Number) AS DiffGroup,Number 
	FROM SomeNumbers),
Islands AS (
	SELECT MIN(Number) AS StartOfIsland, MAX(Number) AS EndOfIsland 
	FROM RowNums
	GROUP BY DiffGroup),
Gaps AS (
	SELECT LAG(Islands.EndOfIsland) OVER(ORDER BY Islands.StartOfIsland) + 1 AS StartOfGap,
			Islands.StartOfIsland -1 EndOfGap
	FROM Islands)
SELECT * 
FROM Gaps 
WHERE StartOfGap IS NOT NULL
ORDER BY Gaps.StartOfGap;











	