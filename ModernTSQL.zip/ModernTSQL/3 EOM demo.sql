USE AdventureWorks2019
GO

--IIF, CONCAT, FORMAT
--STRING_SPLIT
--EOMONTH

SELECT CONCAT(P.BusinessEntityID,'-',P.FirstName,P.MiddleName),P.FirstName + P.MiddleName
FROM person.Person AS P

SELECT DISTINCT OrderDate, 
   DATEADD(DAY,-1,DATEADD(MONTH,1,CAST(YEAR(OrderDate) AS CHAR(4))
	 + '/' + CAST(MONTH(OrderDate) AS CHAR(2)) + '/01')) AS EndOfMonth
FROM Sales.SalesOrderHeader;

--Using Adam Machanic's Thinking Big Adventure tables
--http://dataeducation.com/thinking-big-adventure/
--From 7.8 million row table (25% of Adam's table)
DROP TABLE IF EXISTS #eom; 
CREATE TABLE #eom(origDate DATE, newdate DATE) 
INSERT INTO #eom
(
        origDate,
        newdate
)
SELECT TransactionDate, DATEADD(DAY,-1,DATEADD(MONTH,1,CAST(YEAR(TransactionDate) AS CHAR(4))
     + '/' + CAST(MONTH(TransactionDate) AS CHAR(2)) + '/01'))
FROM AdventureWorks2019.dbo.smallTransactionHistory;

SELECT TOP(10)  * 
FROM #eom
;

--Don't try this at home -- or in production!
DBCC DROPCLEANBUFFERS;

--Use EOMONTH function introduced in 2012
DROP TABLE IF EXISTS #eom; 
CREATE TABLE #eom(origDate DATE, newdate DATE);

INSERT INTO #eom
(
        origDate,
        newdate
)
SELECT TransactionDate, EOMONTH(transactiondate) 
FROM AdventureWorks2019.dbo.smallTransactionHistory;

SELECT TOP 10 * FROM #eom;

--Run on entire table > 31 M rows
DROP TABLE IF EXISTS #eom; 
CREATE TABLE #eom(origDate DATE, newdate DATE);

INSERT INTO #eom
(
        origDate,
        newdate
)
SELECT TransactionDate, EOMONTH(transactiondate) 
FROM AdventureWorks2019.dbo.bigTransactionHistory AS BTH;

SELECT TOP 10 * FROM #eom;

