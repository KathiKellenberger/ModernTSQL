--DEMO Scalar UDF Inlining, 2019
USE AdventureWorks2019;
GO
SET STATISTICS IO ON;
GO
--We are running SQL Server 2017
ALTER DATABASE [AdventureWorks2019] SET COMPATIBILITY_LEVEL = 140;
DROP TABLE IF EXISTS #test
--Results tossed to save time
SELECT  p.ProductID,
        SUM(bth.quantity * (p.ListPrice - p.StandardCost)) AS MarkUp
INTO    #test
FROM    bigProduct p
        JOIN smallTransactionhistory bth
                ON p.productid = bth.productid
GROUP BY p.ProductID;
GO



--Let's add a function because we use this formula a lot!
CREATE OR ALTER FUNCTION dbo.udfGetMarkup
(
        @Quantity INT,
        @ListPrice MONEY,
        @StandardCost MONEY
)
RETURNS MONEY
AS
BEGIN
        RETURN @Quantity * (@ListPrice - @StandardCost);
END;
GO

--We are still running SQL Server 2017
DROP TABLE IF EXISTS #test;
--Use the new wonderful functions!
SELECT  p.ProductID,
        SUM(dbo.udfGetMarkup(bth.Quantity, p.ListPrice, p.StandardCost)) AS MarkUp
INTO    #test
FROM    bigproduct p
        JOIN smalltransactionhistory bth
                ON p.productid = bth.productid
GROUP BY p.ProductID;
--But wait -- this takes a long time!!! Over a minute to run!


--Upgrade to SQL Server 2019!
ALTER DATABASE [AdventureWorks2019] SET COMPATIBILITY_LEVEL = 150;
DROP TABLE IF EXISTS #test;
GO
--Even though we are using the function, it runs fast!
SELECT  p.ProductID,
        SUM(dbo.udfGetMarkup(bth.Quantity, p.ListPrice, p.StandardCost)) AS MarkUp
INTO    #test
FROM    bigproduct p
        JOIN dbo.smallTransactionHistory AS BTH
                ON p.productid = bth.productid
GROUP BY p.ProductID;



GO
--Works with conditional logic
CREATE OR ALTER FUNCTION dbo.udf_OrderQtyForYear_IF(@ProductID INT, @Year INT = NULL) 
RETURNS INT 
AS BEGIN
	DECLARE @EndYear INT;
	IF @Year IS NULL BEGIN 
		SELECT @Year = MAX(YEAR(OrderDate)) + 1, @EndYear = 2999
		FROM Sales.SalesOrderHeader;
	END
	ELSE SET @EndYear = @Year + 1;


	DECLARE @Sum INT;
	SELECT @Sum = SUM(OrderQty)
	FROM Sales.SalesOrderHeader AS SOH 
	JOIN Sales.SalesOrderDetail AS SOD 
		ON SOH.SalesOrderID = SOD.SalesOrderID 
	WHERE SOD.ProductID = @ProductID 
		AND SOH.OrderDate > DATEFROMPARTS(@Year,1,1) 
		AND SOH.OrderDate <= DATEFROMPARTS(@EndYear,1,1);
	RETURN @Sum;
END
GO
SELECT Prod.ProductID, Prod.Name, 2012 AS [Year],
	Prod.Color, dbo.udf_OrderQtyForYear_IF(ProductID, 2012) AS SoldThatYear 
FROM Production.Product AS Prod
ORDER BY SoldThatYear DESC;
GO

--Not if you add a getdate()!
CREATE OR ALTER FUNCTION dbo.udf_OrderQtyForYear_GETDATE(@ProductID INT, @Year INT = NULL) 
RETURNS INT 
AS BEGIN
	DECLARE @EndYear INT;
	
	IF @Year IS NULL BEGIN 
		SELECT @Year = MAX(YEAR(OrderDate)) + 1, @EndYear = YEAR(GETDATE())
		FROM Sales.SalesOrderHeader;
	END
	ELSE SET @EndYear = @Year + 1;


	DECLARE @Sum INT;
	SELECT @Sum = SUM(OrderQty)
	FROM Sales.SalesOrderHeader AS SOH 
	JOIN Sales.SalesOrderDetail AS SOD 
		ON SOH.SalesOrderID = SOD.SalesOrderID 
	WHERE SOD.ProductID = @ProductID 
		AND SOH.OrderDate > DATEFROMPARTS(@Year,1,1) 
		AND SOH.OrderDate <= DATEFROMPARTS(@EndYear,1,1);
	RETURN @Sum;
END
GO

--Is my function inlineable?
SELECT O.Name, M.is_inlineable
FROM sys.sql_modules As M
JOIN sys.objects AS O ON O.object_id = M.object_id
WHERE O.Name LIKE 'udf_OrderQtyForYear%' OR o.name LIKE 'udfGetMarkup%';


