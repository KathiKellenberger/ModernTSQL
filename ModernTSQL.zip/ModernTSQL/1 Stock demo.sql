--DEMO 1
USE DEMO;
SET STATISTICS IO ON;
GO
--3 years and 999 symbols 696,303 rows
SELECT TOP(10) * FROM StockHistory
ORDER BY TradeDate;

SELECT TOP(10) * FROM StockHistory 
WHERE TickerSymbol = 'Z1';

--How to compare ClosePrice to the previous ClosePrice?
--This doesn't work!
SELECT  A.TickerSymbol, A.TradeDate, A.ClosePrice, B.ClosePrice
FROM StockHistory A 
JOIN StockHistory B ON A.TickerSymbol = B.TickerSymbol 
WHERE A.TradeDate > B.TradeDate;



GO
--What about temp table and cursor?
--DO NOT RUN DURING DEMO
DROP TABLE IF EXISTS #Stocks;
CREATE TABLE #Stocks(TickerSymbol VARCHAR(4), 
	TradeDate DATE, 
	ClosePrice DECIMAL(5,2), 
	PrevClosePrice DECIMAL(5,2))

INSERT INTO #Stocks
(
        TickerSymbol,
        TradeDate,
        ClosePrice
)
SELECT TickerSymbol, TradeDate, ClosePrice
FROM StockHistory
;

DECLARE @TickerSymbol VARCHAR(4);
DECLARE @TradeDate DATE;
DECLARE @ClosePrice DECIMAL(5,2);
DECLARE @PrevTickerSymbol VARCHAR(4);
DECLARE @PrevPrice DECIMAL(5,2);


DECLARE StockHistory CURSOR FAST_FORWARD FOR 
	SELECT TickerSymbol, TradeDate, ClosePrice 
	FROM StockHistory
	ORDER BY TickerSymbol, TradeDate;

OPEN StockHistory; 
FETCH NEXT FROM StockHistory INTO	@TickerSymbol, @TradeDate, @ClosePrice; 

WHILE @@FETCH_STATUS = 0 BEGIN 
	IF @PrevTickerSymbol = @TickerSymbol BEGIN 
		UPDATE #Stocks SET PrevClosePrice = @PrevPrice
		WHERE TickerSymbol = @TickerSymbol AND TradeDate = @TradeDate;
	END 
	ELSE BEGIN 
		SET @PrevTickerSymbol = @TickerSymbol;
	END 
	SET @PrevPrice = @ClosePrice
	FETCH NEXT FROM StockHistory INTO @TickerSymbol, @TradeDate, @ClosePrice
END 
CLOSE StockHistory;
DEALLOCATE StockHistory;

--Let it run 2 minutes during practice and 2664 rows processed
SELECT *, ClosePrice - PrevClosePrice AS PriceChange
FROM #Stocks 
WHERE PrevClosePrice IS NOT NULL 
ORDER BY TickerSymbol, TradeDate;

GO






--How about APPLY introduced in 2005?
--Works, but takes 40 seconds to run on entire dataset
SELECT A.TickerSymbol, A.TradeDate, A.ClosePrice, B.PrevPrice, A.ClosePrice - B.PrevPrice AS PriceChange
FROM StockHistory AS A 
OUTER APPLY (
	SELECT TOP(1) ClosePrice AS PrevPrice
	FROM StockHistory 
	WHERE TickerSymbol = A.TickerSymbol 
		AND TradeDate < A.TradeDate		
	ORDER BY TradeDate DESC) AS B 
WHERE A.TickerSymbol IN ('Z1','Z2','Z3','Z4')
ORDER BY A.TickerSymbol, A.TradeDate;


--The best solution!!! LAG
SELECT TickerSymbol, TradeDate, ClosePrice, 
	LAG(ClosePrice) OVER(PARTITION BY TickerSymbol ORDER BY TradeDate) AS PrevPrice, 
	ClosePrice - LAG(ClosePrice) 
	OVER(PARTITION BY TickerSymbol ORDER BY TradeDate) AS PriceChange
FROM StockHistory
ORDER BY TickerSymbol, TradeDate;
