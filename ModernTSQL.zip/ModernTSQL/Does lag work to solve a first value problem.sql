USE AdventureWorks2019;
SET STATISTICS IO ON;
GO
--Here is first value, the first order id for each customer
SELECT SOH.SalesOrderID, SOH.CustomerID, 
	FIRST_VALUE(SOH.SalesOrderID) 
	OVER(PARTITION BY SOH.CustomerID ORDER BY SOH.SalesOrderID
	ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS FirstValue
FROM Sales.SalesOrderHeader AS SOH;

--To solve the same problem using LAG, you have to determine
--how many rows to go back for each row in the results.
--I used a running total to do that.
--This doesn't perform as well as first value
--Use the correct tool for the job!
WITH cust AS (
	SELECT SOH.CustomerID, SOH.SalesOrderID, 
		COUNT(*) OVER(PARTITION BY SOH.CustomerID ORDER BY SOH.SalesOrderID
		ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) -1 AS CustOffset
	FROM Sales.SalesOrderHeader AS SOH)
SELECT CustomerID, cust.SalesOrderID, 
	LAG(SalesOrderID,CustOffset) 
	OVER(PARTITION BY cust.CustomerID ORDER BY cust.SalesOrderID) AS FirstValue
FROM Cust;

