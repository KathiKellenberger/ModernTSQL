USE AdventureWorks2019
GO

--IIF, CONCAT, FORMAT
--STRING_SPLIT
--EOMONTH

SELECT CONCAT(P.BusinessEntityID,'-',P.FirstName,P.MiddleName),P.FirstName + P.MiddleName
FROM person.Person AS P

SELECT DISTINCT OrderDate, 
   DATEADD(DAY,-1,DATEADD(MONTH,1,CAST(YEAR(OrderDate) AS CHAR(4))
	 + '/' + CAST(MONTH(OrderDate) AS CHAR(2)) + '/01')) AS EndOfMonth
FROM Sales.SalesOrderHeader;

--Using Adam Machanic's Thinking Big Adventure tables
--http://dataeducation.com/thinking-big-adventure/
--From 7.8 million row table (25% of Adam's table)
DROP TABLE IF EXISTS #eom; 
CREATE TABLE #eom(origDate DATE, newdate DATE) 
INSERT INTO #eom
(
        origDate,
        newdate
)
SELECT TransactionDate, DATEADD(DAY,-1,DATEADD(MONTH,1,CAST(YEAR(TransactionDate) AS CHAR(4))
     + '/' + CAST(MONTH(TransactionDate) AS CHAR(2)) + '/01'))
FROM AdventureWorks2019.dbo.smallTransactionHistory;

SELECT TOP(10)  * 
FROM #eom
;

--Don't try this at home -- or in production!
DBCC DROPCLEANBUFFERS;

--Use EOMONTH function introduced in 2012
DROP TABLE IF EXISTS #eom; 
CREATE TABLE #eom(origDate DATE, newdate DATE);

INSERT INTO #eom
(
        origDate,
        newdate
)
SELECT TransactionDate, EOMONTH(transactiondate) 
FROM AdventureWorks2019.dbo.smallTransactionHistory;

SELECT TOP 10 * FROM #eom;

--Run on entire table > 31 M rows
DROP TABLE IF EXISTS #eom; 
CREATE TABLE #eom(origDate DATE, newdate DATE);

INSERT INTO #eom
(
        origDate,
        newdate
)
SELECT TransactionDate, EOMONTH(transactiondate) 
FROM AdventureWorks2019.dbo.bigTransactionHistory AS BTH;

SELECT TOP 10 * FROM #eom;

SELECT p.ProductID + Name + color 
from bigproduct p 
join bigtransactionhistory t 
on p.productid = t.productid;

SELECT CAST(p.ProductID as varchar(30)) + Name + color 
from bigproduct p 
join bigtransactionhistory t 
on p.productid = t.productid;

SELECT CAST(p.productid as varchar(30)) + Name + ISNULL(color,'')
from bigproduct p 
join bigtransactionhistory t 
on p.productid = t.productid;

SELECT CONCAT(p.productid, Name, color)
from bigproduct p 
join bigtransactionhistory t 
on p.productid = t.productid;


DBCC DROPCLEANBUFFERS 
GO
DROP TABLE IF EXISTS #Products;
CREATE TABLE #Products(Description varchar(200));

--34 seconds
INSERT INTO #Products(Description) 
SELECT CAST(p.productid as varchar(30)) + Name + ISNULL(color,'')
from bigproduct p 
join bigtransactionhistory t 
on p.productid = t.productid;

DBCC DROPCLEANBUFFERS 
GO
DROP TABLE IF EXISTS #Products;
CREATE TABLE #Products(Description varchar(200));

--31 seconds
INSERT INTO #Products(Description) 
SELECT CONCAT(p.productid, Name, color)
from bigproduct p 
join bigtransactionhistory t 
on p.productid = t.productid;


DBCC DROPCLEANBUFFERS 
GO
DROP TABLE IF EXISTS #Products;
CREATE TABLE #Products(Description varchar(200));

--30 seconds
INSERT INTO #Products(Description) 
SELECT name + color
from bigproduct p 
join bigtransactionhistory t 
on p.productid = t.productid;

DBCC DROPCLEANBUFFERS 
GO
DROP TABLE IF EXISTS #Products;
CREATE TABLE #Products(Description varchar(200));

--30 seconds
INSERT INTO #Products(Description) 
SELECT concat(name,color)
from bigproduct p 
join bigtransactionhistory t 
on p.productid = t.productid;



DBCC DROPCLEANBUFFERS 
GO
DROP TABLE IF EXISTS #Products;
CREATE TABLE #Products(Description varchar(200));
--30 seconds
INSERT INTO #Products(Description) 
SELECT cast(p.productid as varchar(20)) + name 
from bigproduct p 
join bigtransactionhistory t 
on p.productid = t.productid;

DBCC DROPCLEANBUFFERS 
GO
DROP TABLE IF EXISTS #Products;
CREATE TABLE #Products(Description varchar(200));

--30 seconds
INSERT INTO #Products(Description) 
SELECT concat(p.productid, name)
from bigproduct p 
join bigtransactionhistory t 
on p.productid = t.productid;



DBCC DROPCLEANBUFFERS 
GO
DROP TABLE IF EXISTS #Products;
CREATE TABLE #Products(Description varchar(200));
--36 seconds
INSERT INTO #Products(Description) 
SELECT cast(p.productid as varchar(20)) + name + isnull(color,'') + isnull(color,'')
from bigproduct p 
join bigtransactionhistory t 
on p.productid = t.productid;

DBCC DROPCLEANBUFFERS 
GO
DROP TABLE IF EXISTS #Products;
CREATE TABLE #Products(Description varchar(200));

--33 seconds
INSERT INTO #Products(Description) 
SELECT concat(p.productid, name,color,color)
from bigproduct p 
join bigtransactionhistory t 
on p.productid = t.productid;


--FORMAT

SELECT top(100) transactiondate, CONVERT(char(10),Transactiondate,101),format(TransactionDate,'MM/dd/yyyy')
FROM BigTransactionHistory

dbcc dropcleanbuffers
drop table if exists #Dates
create table #dates(formatteddate date)

--34
INSERT INTO #dates(formatteddate) 
select convert(char(10),transactiondate,101)
from bigtransactionhistory

dbcc dropcleanbuffers
drop table if exists #Dates
create table #dates(formatteddate date)

-- >2 minutes
INSERT INTO #dates(formatteddate) 
select format(transactiondate,'MM/dd/yyyy')
from bigtransactionhistory

